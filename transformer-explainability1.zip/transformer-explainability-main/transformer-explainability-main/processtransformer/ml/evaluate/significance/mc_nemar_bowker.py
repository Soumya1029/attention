# https://www.real-statistics.com/non-parametric-tests/mcnemar-bowker-test/
# https://peterstatistics.com/CrashCourse/4-TwoVarPair/NomNom/NomNomPair3.html
# https://raw.githubusercontent.com/linux08/machine-learning-books/master/Evaluating%20Learning%20Algorithms%20-%20A%20Classification%20Perspective%202011.pdf
# Also interesting:
# https://towardsdatascience.com/statistical-tests-for-comparing-machine-learning-and-baseline-performance-4dfc9402e46f
