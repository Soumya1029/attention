# https://stats.stackexchange.com/questions/400995/t-sne-with-mixed-continuous-and-binary-variables
# Idee:
# Trainiere Embeddings für die einzelnen Aktivitäten
def compare_augmented_and_non_augmented_data():

    pass
